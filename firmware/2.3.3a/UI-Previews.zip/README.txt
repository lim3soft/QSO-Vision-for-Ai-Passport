QSO VISION 2.3.3a — native UI renders with sample data, not device photographs or live QSO records. limesoft (9W3SPY). Flag artwork: flag-icons, MIT; full license included.
