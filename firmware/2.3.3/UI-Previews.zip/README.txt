QSO VISION 2.3.3. Native UI renders with sample data, not physical-device photographs or live QSO records. limesoft (9W3SPY).
